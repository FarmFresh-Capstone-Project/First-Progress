import Home from '../views/pages/home';

const routes = {
  '/': Home, // default page
  '/home': Home,
};

export default routes;
