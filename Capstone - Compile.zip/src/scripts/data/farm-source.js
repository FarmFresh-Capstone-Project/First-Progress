const vegetable = [
  {
    id: 1,
    name: 'Item 1',
    store: 'Store 1',
    rating: 4.5,
    description: 'This is a description for Item 1.',
  },
  {
    id: 2,
    name: 'Item 2',
    store: 'Store 2',
    rating: 4.7,
    description: 'This is a description for Item 2.',
  },
  {
    id: 3,
    name: 'Item 3',
    store: 'Store 3',
    rating: 4.2,
    description: 'This is a description for Item 3.',
  },
  {
    id: 4,
    name: 'Item 4',
    store: 'Store 4',
    rating: 4.8,
    description: 'This is a description for Item 4.',
  },
  {
    id: 5,
    name: 'Item 5',
    store: 'Store 5',
    rating: 4.6,
    description: 'This is a description for Item 5.',
  },
  {
    id: 6,
    name: 'Item 6',
    store: 'Store 6',
    rating: 4.9,
    description: 'This is a description for Item 6.',
  },
  {
    id: 7,
    name: 'Item 7',
    store: 'Store 7',
    rating: 4.1,
    description: 'This is a description for Item 7.',
  },
  {
    id: 8,
    name: 'Item 8',
    store: 'Store 8',
    rating: 4.4,
    description: 'This is a description for Item 8.',
  },
  {
    id: 9,
    name: 'Item 9',
    store: 'Store 9',
    rating: 4.3,
    description: 'This is a description for Item 9.',
  },
  {
    id: 10,
    name: 'Item 10',
    store: 'Store 10',
    rating: 4.0,
    description: 'This is a description for Item 10.',
  },
];

export default vegetable;
